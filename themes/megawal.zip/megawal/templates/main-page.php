<?php
/*
Template Name: Main page
*/


 get_header();
  get_template_part( 'template-parts/content', 'page' );
 ?>
 
     <main id="primary" class="site-main">
         <?php

?>
</main>
 <?php
 get_sidebar();
 get_footer();
 



?>
