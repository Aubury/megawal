<?php

use Carbon_Fields\Container;
use Carbon_Fields\Field;

 
Container::make( 'theme_options', __( 'Сдайдер банера' ) )
->set_page_parent( 'themes.php' ) 
->add_fields( array(
    
    Field::make( 'complex', 'slider_content', 'Слайдер, максимум 5 изображений' )->set_layout( 'tabbed-vertical' )->set_max( 5 )
	->add_fields( array(
        Field::make( 'image', 'photo', __( ' Photo' ) )->set_width( 30 ),
        Field::make( 'text', 'title', __( ' Альтернативный текст для изображения "Alt"' ) )->set_width( 70 ),
	) ),
    Field::make( 'rich_text', 'offer', __( ' Оффер' ) ),

) );


